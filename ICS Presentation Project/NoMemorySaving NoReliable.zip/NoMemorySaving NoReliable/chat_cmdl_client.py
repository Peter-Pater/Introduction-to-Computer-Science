
from chat_client_class import *

def main():
    client = Client()
    client.run_chat()
    
main()
